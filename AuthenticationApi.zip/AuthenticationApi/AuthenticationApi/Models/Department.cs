﻿using System;
using System.Collections.Generic;

namespace AuthenticationApi.Models;

public partial class Department
{
    public string Name { get; set; } = null!;

    public string Location { get; set; } = null!;
}
