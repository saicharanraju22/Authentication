﻿using System;
using System.Collections.Generic;

namespace AuthenticationApi.Models;

public partial class Role
{
    public int Id { get; set; }

    public string? Rolename { get; set; }
}
