﻿using System;
using System.Collections.Generic;

namespace AuthenticationApi.Models;

public partial class Employee
{
    public string Username { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Role { get; set; } = null!;

    public string Department { get; set; } = null!;
}
