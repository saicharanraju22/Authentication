
using AuthenticationApi.helper;
using AuthenticationApi.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;

var builder = WebApplication.CreateBuilder(args);



// Add services to the container.
var connectionString = builder.Configuration["DbContextSettings:Db"];




builder.Services.AddDbContext<AuthenticationContext>(dbcontextoption => dbcontextoption.UseSqlServer(connectionString));


builder.Services.AddAuthentication(opt =>
{
    opt.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    opt.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = "https://localhost:7080",
            ValidAudience = "https://localhost:7080",
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("secretkey@34567secretkey@3456@3456"))
        };
    });

builder.Services.AddAuthorization(policies =>
{

    policies.AddPolicy(Employeeroles.Admin, policy => policy.RequireClaim(ClaimTypes.Role, new List<string> { Employeeroles.Admin }));
    policies.AddPolicy(Employeeroles.MANAGER, policy => policy.RequireClaim(constant.Claimtype, new List<string> { Employeeroles.MANAGER }));
    policies.AddPolicy(Employeeroles.EMPLOYEE, policy => policy.RequireClaim(constant.Claimtype, new List<string> { Employeeroles.EMPLOYEE }));

});

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();



app.MapControllerRoute(
    name: "default",
    pattern: "{controller}/{action=Index}/{id?}");



app.Run();
