﻿using System.Security.Claims;

namespace AuthenticationApi.helper
{
    public static class constant
    {
        public const string Claimtype= "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";


    }

    public static class Employeeroles
    {
       
        public const string EMPLOYEE = "Employee";
        public const string MANAGER = "Manager";
        public const string Admin = "Admin";




    }
}
