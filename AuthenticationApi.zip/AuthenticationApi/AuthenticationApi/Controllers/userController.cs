﻿
using AuthenticationApi.helper;
using AuthenticationApi.Models;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace AuthenticationApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class userController : ControllerBase
    {
        private readonly AuthenticationContext _context;
        public userController(AuthenticationContext context)
        {
            _context = context;
        }

        [HttpPost("generate")]
        public IActionResult GenerateToken(string username, string password)
        {
            var employee = _context.Employees.FirstOrDefault(e => e.Username == username && e.Password == password);
            if (employee == null)
            {
                return BadRequest("Invalid username or password");
            }
            var claims = new[]
            {
                  new Claim(ClaimTypes.Role, employee.Role)
            };
            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("secretkey@34567secretkey@3456@3456"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: "https://localhost:7080",
                audience: "https://localhost:7080",
                claims: claims,
                expires: DateTime.UtcNow.AddDays(45),
                signingCredentials: creds
            );
            return Ok(new JwtSecurityTokenHandler().WriteToken(token));
        
        }



        [Authorize(Policy = Employeeroles.Admin)]
        [HttpGet("Employee")]
        public ActionResult GetEmployeedetails()
        {
            var user = User;
            var details = _context.Employees.ToList();
            return Ok(details);
        }





        [Authorize(Policy = Employeeroles.MANAGER)]
        [HttpGet("Roles")]
        public ActionResult GetRoledetails()
        {
            var user = User;
            var details = _context.Roles.Select(x=>x.Rolename);
            return Ok(details);
        }


        [Authorize]
        [HttpGet("Employeerole")]
        public ActionResult GetRoledetail()
        {
            //getting user claims
            var user = User;

            return Ok(user.FindFirstValue(ClaimTypes.Role));
        }




    }
}
